/** Automatically generated file. DO NOT MODIFY */
package c9.edu.lab411.sensortracking;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
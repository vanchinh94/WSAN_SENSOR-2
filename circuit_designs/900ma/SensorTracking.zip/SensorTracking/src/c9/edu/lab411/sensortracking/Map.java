package c9.edu.lab411.sensortracking;

public class Map {
	private int node;
	public Map(int node) {
		this.node = node;
	}
	public Map() {
	}
	public int getNode() {
		return node;
	}
	public void setNode(int node) {
		this.node = node;
	}
}
